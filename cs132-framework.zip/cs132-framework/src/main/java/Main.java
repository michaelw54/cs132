public class Main{
    public static void main(String [] args) {
        /* This is a placeholder file, 
            please create a new class with required name for the homework
            and remove this file */
    }
}