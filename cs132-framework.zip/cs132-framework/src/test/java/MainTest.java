import org.junit.Test;
import static org.junit.Assert.*;

public class MainTest {
    @Test public void testAppHasAGreeting() {
        assertEquals(true, true);
    }
}
