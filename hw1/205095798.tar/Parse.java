public class Parse {
    public static void main(String[] args) {
        Parser p = new Parser();
        p.parse();
    }
}